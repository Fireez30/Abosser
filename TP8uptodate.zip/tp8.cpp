#include "ImageBase.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string.h>
#include "CBlock.h"

using namespace std;

namespace {
    void LoadFiles(vector<string> & FileName, int number){
        cout << "Ecriture des fichiers dans le vector de noms " << endl;
        for (unsigned i (0); i < number; i++)
            FileName[i] = "BanqueImage/" + to_string(i) + ".pgm";
    }

    vector<CBlock> divisionImage(ImageBase & ImgIn, int pas){
        cout << "Division de l image en blocs " << endl;
        vector<CBlock> result;

        for (unsigned i (0); i < ImgIn.getHeight(); i += pas)
            for (unsigned j (0); j < ImgIn.getWidth(); j += pas){
                CBlock tmp (i, i + pas, j, j + pas);
                result.push_back(tmp);
            }

        return result;
    }

    void CreateBlockImage (ImageBase & Img, char* cNomImgEcrite, vector<CBlock> & blocs) {
        ImageBase ImgOut(Img.getWidth(), Img.getHeight(), Img.getColor());

        for(int y = 0; y < blocs.size(); y++)
        {
            blocs[y].CritereWithMoyenne(Img);
            for (int i = blocs[y].getxMin(); i < blocs[y].getxMax(); i ++)
                for (int j = blocs[y].getyMin(); j < blocs[y].getyMax(); j ++){
                    ImgOut[i][j] = blocs[y].getCritere();
                }
        }
        ImgOut.save(cNomImgEcrite);
    }

    ImageBase resizeImageBy2(ImageBase & ImgIn){
        cout << "resizeImageBy2" << endl;
        ImageBase ImgOut (ImgIn.getWidth() / 2, ImgIn.getHeight() / 2, ImgIn.getColor());

        int cpti = 0;
        int cptj = 0;

        for (unsigned i (0); i < ImgIn.getHeight(); i += 2){
            for (unsigned j (0); j < ImgIn.getWidth() - 1; j += 2){
                int moyenne = (ImgIn[i][j] + ImgIn[i][j+1]) / 2;
                ImgOut[cpti][cptj] = moyenne;
                cptj++;
            }
            cpti++;
            cptj = 0;
        }
        cout << "Avant le return imagesizeby2" << endl;
        return ImgOut;
    }

    ImageBase resizeImageToBlockSize(ImageBase ImgIn, CBlock Bloc){
        cout << "Resize de l'image ! " << endl;
        ImageBase tmp = ImgIn;
        ImageBase result;
        int cpt = 0;
        while (tmp.getWidth() > Bloc.getxMax() - Bloc.getxMin()){
            cout << "Tour de resize : " << cpt << endl;
            result = resizeImageBy2(tmp);
            cout << "Retour dans resizeImage classique" << endl;
            tmp = result;
            cpt++;
             cout << "Tour suivant ! " << endl;
        }
        cout << "fin resize image" << endl;
        return result;
    }

    void applyBlockToImage(ImageBase & ImgIn, CBlock Bloc){
        ImageBase use;
        ImageBase resized;

        use = Bloc.getImageUtile();
        resized = resizeImageToBlockSize(use,Bloc);
        cout << "test" << endl;
        int cmpimageX = 0;
        int cmpimageY = 0;

        for (int i = Bloc.getxMin(); i < Bloc.getxMax(); i++){
            for (int j = Bloc.getyMin(); j < Bloc.getyMax(); j++){
                ImgIn[i][j] = resized[cmpimageX][cmpimageY];
                cmpimageY++;
            }
            cmpimageX++;
            cmpimageY=0;
        }
    }

    void ecritureMoyennesBanque(const vector<string> & FileName){
        cout << "Ecriture des moyennes ! " << endl;
        ofstream File ("moyennes.csv", ios::out | ios::ate);
        if (File){
            cout << "Fichier ouvert ! " << endl;
        }
        else {
            cout << "Erreur lors de l'ouverture" << endl;
            exit(-1);
        }

        for (int i = 0; i < FileName.size(); i++){
            ImageBase ImgIn;
            int moyenne = 0;
            string str = FileName[i];
            char *cstr = new char[str.length()];
            strcpy(cstr, str.c_str());
            ImgIn.load(cstr);

            double Total = 0.0;

            for (unsigned i (0); i < ImgIn.getHeight(); ++i)
                for (unsigned j (0); j < ImgIn.getWidth(); ++j)
                    Total += ImgIn[i][j];

            moyenne = ((int) Total / ImgIn.getTotalSize());


            File << FileName[i] << " " << moyenne << endl;
        }
        File.close();
    }

    int getMoyenneWithPicName(string pic){
        ifstream File("moyennes.csv", ios::in);
        if (File){
            cout << "Fichier ouvert ! " << endl;
        }
        else {
            cout << "Erreur lors de l'ouverture" << endl;
            exit(-1);
        }

        while (!File.eof()){
            string name;
            int moyenne;

            File >> name >> moyenne;
            if (name == pic)
                return moyenne;
        }

        cout << "Image non trouvée ! " << endl;
        return -1;
    }

    vector<pair<string, int>> getAllMoy () {
        cout << "Recuperation des moyennes " << endl;
        ifstream File("moyennes.csv", ios::in);
        if (File){
            cout << "Fichier ouvert ! " << endl;
        }
        else {
            cout << "Erreur lors de l'ouverture" << endl;
            exit(-1);
        }

        vector<pair<string, int>> AllMoy;

        while (!File.eof()) {
            pair<string, int> CurrentPair;

            File >> CurrentPair.first >> CurrentPair.second;
            cout << "Recuperation d'une nouvelle paire " << endl;
            AllMoy.push_back(CurrentPair);
        }
        cout << "Fin recuperation des moyennes " << endl;
        return AllMoy;
    }

}

int main(int argc, char **argv)
{
    char cNomImgEcrite[250];
    if (argc != 2)
    {
        cout << "Usage: ImageIn.pgm ImageOut.pgm" << endl;
        return -1;
    }
    sscanf(argv[1],"%s",cNomImgEcrite);

    vector<string> FileName (10001);
    LoadFiles(FileName,10001);

    string ts;
    cout << "Mise a jour des moyennes necessaire ? oui ou non" << endl;
    cin >> ts;

    if (ts == "oui"){
        ecritureMoyennesBanque(FileName);
    }

    ImageBase ImgIn;
    string str = "MHX.pgm";
    char *cstr = new char[str.length()];
    strcpy(cstr, str.c_str());
    cout << "Nom imagee " << cstr << endl;
    ImgIn.load(cstr);
    cout << "Image de base chargée ! " << endl;

    vector<CBlock> blocs = divisionImage(ImgIn,16);
    
    vector<pair<string,int>> Ms = getAllMoy();

    for (int i = 0; i < blocs.size(); i++){
        blocs[i].DistanceWithMoyenne(Ms);
        applyBlockToImage(ImgIn,blocs[i]);
    }

    ImgIn.save("result.pgm");

    return 0;

}
