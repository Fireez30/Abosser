#include "Voxel.h"
 
// Construcentreors
Voxel::Voxel() {}
Voxel::~Voxel() {
  CentresDivisions->clear();
  Coins->clear();
}
 
Voxel::Voxel(CPoint* centre, double l) {
    this->centre = centre;
    this->l = l;
    this->CentresDivision = new std::vector<CPoint>();
    this->Coins = new std::vector<CPoint>();
    computeDivision();
    computeCoins();
}
 
CPoint*  Voxel::getCenter() {
    return centre;
}
double Voxel::getLength() {
    return l;
}
 
std::vector<CPoint>* Voxel::getCoins() {
    return Coins;
}
 
std::vector<CPoint>* Voxel::getCentresDivisions() {
    return CentresDivision;
}
 
void Voxel::tracePoint(CPoint *A, float x,float y,float z) {
  glColor3f(x,y,z);
  glBegin(GL_POINTS);
    glVertex3f(A->getX(),A->getY(),A->getZ());
    glEnd();
}
 
void  Voxel::trace(CPoint* A, CPoint* B,CPoint* C,CPoint* D,  float x,float y,float z) {
  glColor3f(x,y,z);
  glBegin(GL_QUADS);
    glVertex3f(A->getX(),A->getY(),A->getZ());
    glVertex3f(B->getX(),B->getY(),B->getZ());
    glVertex3f(C->getX(),C->getY(),C->getZ());
    glVertex3f(D->getX(),D->getY(),D->getZ());
  glEnd();
}
 
void Voxel::AfficheVoxel() { // Point center, double length
  CPoint* a = new CPoint(centre->getX()+l/2, centre->getY()-l/2, centre->getZ()-l/2);
  CPoint* b = new CPoint(centre->getX()+l/2, centre->getY()+l/2, centre->getZ()-l/2);
  CPoint* c = new CPoint(centre->getX()-l/2, centre->getY()-l/2, centre->getZ()-l/2);
  CPoint* d = new CPoint(centre->getX()-l/2, centre->getY()+l/2, centre->getZ()-l/2);
  CPoint* e = new CPoint(centre->getX()+l/2, centre->getY()-l/2, centre->getZ()+l/2);
  CPoint* f = new CPoint(centre->getX()+l/2, centre->getY()+l/2, centre->getZ()+l/2);
  CPoint* g = new CPoint(centre->getX()-l/2, centre->getY()-l/2, centre->getZ()+l/2);
  CPoint* h = new CPoint(centre->getX()-l/2, centre->getY()+l/2, centre->getZ()+l/2);
 
  trace(a,b,d,c,255,0,0);
  trace(a,c,g,e,0,255,0);
  trace(d,c,g,h,255,255,0);
  trace(b,d,h,f,0,255,0);
  trace(a,b,f,e,255,0,0);
  trace(e,f,h,g,255,255,0);

}
 
void Voxel::computeDivision() {    
    CentresDivision->push_back(CPoint(centre->getX()-l/4, centre->getY()+l/4, centre->getZ()-l/4));
    CentresDivision->push_back(CPoint(centre->getX()-l/4, centre->getY()-l/4, centre->getZ()-l/4));
    CentresDivision->push_back(CPoint(centre->getX()+l/4, centre->getY()-l/4, centre->getZ()-l/4));
    CentresDivision->push_back(CPoint(centre->getX()+l/4, centre->getY()+l/4, centre->getZ()-l/4));
    CentresDivision->push_back(CPoint(centre->getX()-l/4, centre->getY()-l/4, centre->getZ()+l/4));
    CentresDivision->push_back(CPoint(centre->getX()-l/4, centre->getY()+l/4, centre->getZ()+l/4));
    CentresDivision->push_back(CPoint(centre->getX()+l/4, centre->getY()-l/4, centre->getZ()+l/4));
    CentresDivision->push_back(CPoint(centre->getX()+l/4, centre->getY()+l/4, centre->getZ()+l/4));
}
 
void Voxel::computeCoins() {
    Coins->push_back(CPoint(centre->getX()-l/2, centre->getY()+l/2, centre->getZ()-l/2));
    Coins->push_back(CPoint(centre->getX()-l/2, centre->getY()-l/2, centre->getZ()-l/2));
    Coins->push_back(CPoint(centre->getX()+l/2, centre->getY()-l/2, centre->getZ()-l/2));
    Coins->push_back(CPoint(centre->getX()+l/2, centre->getY()+l/2, centre->getZ()-l/2));
    Coins->push_back(CPoint(centre->getX()-l/2, centre->getY()-l/2, centre->getZ()+l/2));
    Coins->push_back(CPoint(centre->getX()-l/2, centre->getY()+l/2, centre->getZ()+l/2));
    Coins->push_back(CPoint(centre->getX()+l/2, centre->getY()-l/2, centre->getZ()+l/2));
    Coins->push_back(CPoint(centre->getX()+l/2, centre->getY()+l/2, centre->getZ()+l/2));
}
 
void Voxel::displayDivision() {
    Voxel* temp;
    for(int i =0; i<8; i++)
    {
        temp = new Voxel(&CentresDivision->at(i),(double)l/2.0);
        temp->AfficheVoxel();
    }
}

void Voxel::traceSquelette(){
  glColor3f(1,0,0);
  glBegin(GL_LINES);
  glVertex3f(Coins->at(0).getX(), Coins->at(0).getY(), Coins->at(0).getZ());
  glVertex3f(Coins->at(1).getX(), Coins->at(1).getY(), Coins->at(1).getZ());

  glVertex3f(Coins->at(0).getX(), Coins->at(0).getY(), Coins->at(0).getZ());
 glVertex3f(Coins->at(5).getX(), Coins->at(5).getY(), Coins->at(5).getZ());

 glVertex3f(Coins->at(5).getX(), Coins->at(5).getY(), Coins->at(5).getZ());
 glVertex3f(Coins->at(4).getX(), Coins->at(4).getY(), Coins->at(4).getZ());
 

 glVertex3f(Coins->at(4).getX(), Coins->at(4).getY(), Coins->at(4).getZ());
 glVertex3f(Coins->at(1).getX(), Coins->at(1).getY(), Coins->at(1).getZ());


glVertex3f(Coins->at(7).getX(), Coins->at(7).getY(), Coins->at(7).getZ());
 glVertex3f(Coins->at(5).getX(), Coins->at(5).getY(), Coins->at(5).getZ());

  glVertex3f(Coins->at(7).getX(), Coins->at(7).getY(), Coins->at(7).getZ());
  glVertex3f(Coins->at(6).getX(), Coins->at(6).getY(), Coins->at(6).getZ());

   glVertex3f(Coins->at(5).getX(), Coins->at(5).getY(), Coins->at(5).getZ());
  glVertex3f(Coins->at(4).getX(), Coins->at(4).getY(), Coins->at(4).getZ());

  glVertex3f(Coins->at(4).getX(), Coins->at(4).getY(), Coins->at(4).getZ());
  glVertex3f(Coins->at(6).getX(), Coins->at(6).getY(), Coins->at(6).getZ());


  glVertex3f(Coins->at(2).getX(), Coins->at(2).getY(), Coins->at(2).getZ());
  glVertex3f(Coins->at(1).getX(), Coins->at(1).getY(), Coins->at(1).getZ());

  glVertex3f(Coins->at(2).getX(), Coins->at(2).getY(), Coins->at(2).getZ());
  glVertex3f(Coins->at(3).getX(), Coins->at(3).getY(), Coins->at(3).getZ());

  glVertex3f(Coins->at(2).getX(), Coins->at(2).getY(), Coins->at(2).getZ());
  glVertex3f(Coins->at(6).getX(), Coins->at(6).getY(), Coins->at(6).getZ());

  glVertex3f(Coins->at(3).getX(), Coins->at(3).getY(), Coins->at(3).getZ());
  glVertex3f(Coins->at(7).getX(), Coins->at(7).getY(), Coins->at(7).getZ());
  glEnd();
}
 
int Voxel::isInsideSphere(CPoint* centres, double ray) { // return 1 if vox inside Sphere,
                                                    //  return 0 if outside
                                                    // return 2 if intersecentreion
    int retour = 0;
    int cpt = 0;

    for(int k=0; k<8; k++)
    {
        if(Coins->at(k).isInsideSphere(centres, ray)==1)
        {
            retour = 1;
            cpt++;
        }
    }
    if(cpt<7 && cpt>0)
        return 2;
    else
        return retour;
}


int Voxel::isInsideCylinder(CPoint* centres, CVector* v,double ray) { // return 1 if vox inside Sphere,
                                                    //  return 0 if outside
                                                    // return 2 if intersecentreion
    int retour = 0;
    int cpt = 0;

    for(int k=0; k<8; k++)
    {
        if(Coins->at(k).isInsideCylinder(centres,v,ray)==1)
        {
            retour = 1;
            cpt++;
        }
    }
    if(cpt<8 && cpt>0)
        return 2;
    else
        return retour;
}