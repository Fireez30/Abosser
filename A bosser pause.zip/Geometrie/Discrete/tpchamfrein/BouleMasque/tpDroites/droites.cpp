
#include <stdio.h>
#include <math.h>
#include <queue>
#include <iostream>
#include "ImageBase.h"
#include "Pixel.h"

using namespace std;

void Bresenham(int argc,char** argv){
  char cNomImgEcrite[250];
  int tailleImage;
  int epaisseur;
  
  if (argc != 4){
    printf("Usage: ImageOut.pgm RayonImage Epaisseur\n"); 
    exit(-1);
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&tailleImage) ;
  scanf (argv[3],"%d",&epaisseur) ;

  ImageBase ImgOut(tailleImage,tailleImage, false);

  for(int i = 0; i < tailleImage; i++){
      for(int j = 0; j < tailleImage; j++)
        if (i == 0 || j == 0 ) ImgOut[i][j] = 255;
        else 
          ImgOut[i][j] == 0;
  }

  int x0 = 20;
  int x1 = 100;

  int y0 = 40;
  int y1 = 110;

  int dx = x1 - x0;
  int dy = y1 - y0;
  int x;
  int y = y0;

  int incrHor = 2*dy;
  int incrDiag = 2*(dx - dy);
  int e = 2*dy - dx;

  for (int x = x0; x <= x1; x++)
{
  
  int tmp = epaisseur;
  while (tmp > 0) 
    {
      int tmp = epaisseur;
      ImgOut[((int) tmp/2) + x][((int) tmp/2) + y] = 255;
      tmp--;
    }

    ImgOut[x][y] = 255;

  if (e >= 0){
    y++;
    e = e - incrDiag;
  }
  else 
    e = e + incrHor;
} 

 ImgOut.save(cNomImgEcrite);

}


void Reveilles(int argc,char** argv){
  char cNomImgEcrite[250];
  int tailleImage;
   int epaisseur;
  
  if (argc != 4){
    printf("Usage: ImageOut.pgm RayonImage Epaisseur\n"); 
    exit(-1);
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&tailleImage) ;
  scanf (argv[3],"%d",&epaisseur) ;

  ImageBase ImgOut(tailleImage,tailleImage, false);

  for(int i = 0; i < tailleImage; i++){
      for(int j = 0; j < tailleImage; j++)
        if (i == 0 || j == 0 ) ImgOut[i][j] = 255;
        else 
          ImgOut[i][j] == 0;
  }

  int x0 = 2;
  int x1 = 7;

  int y0 = 1;
  int y1 = 10;
  int vx = x1 - x0;
  int vy = y1 - y0;

  int u = vy*x0 - vx*y0;
  int r = vy*x0 - vx*y0 - u;
  
  int x = x0;
  int y = y0;


  while (x < x1)
{
  x++;
  r = r + vy;
  if (r < 0 || r >= vx){
    y++;
    r = r - vx;
  }

  int tmp = epaisseur;
  while (tmp > 0) 
    {
      int tmp = epaisseur;
      ImgOut[((int) tmp/2) + x][((int) tmp/2) + y] = 255;
      tmp--;
    }

    ImgOut[x][y] = 255;
} 

 ImgOut.save(cNomImgEcrite);

}

int main(int argc, char** argv)
{

  string tmp;
  cout << "Algorithme ? r pour Reveilles , b pour Bresenham " << endl;
  cin >> tmp;
 
 if (tmp == "r") 
  Reveilles(argc,argv);
 else if (tmp == "b")
  Bresenham(argc,argv);
 else 
  {
    cout << "Mauvais choix d'Algorithme !" << endl;
  }
  return 0;
}
