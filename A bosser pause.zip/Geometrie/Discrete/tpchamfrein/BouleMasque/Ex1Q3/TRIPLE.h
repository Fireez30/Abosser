
#ifndef TRIPLE_H_
#define TRIPLE_H_

class TRIPLE{
	public:
		int x,y,z;
		TRIPLE(int x,int y,int z);
		int getX();
		int getY();
		int getZ();

};

#endif 

