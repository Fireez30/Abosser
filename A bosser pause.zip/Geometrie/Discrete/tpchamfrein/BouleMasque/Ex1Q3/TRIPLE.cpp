#include "TRIPLE.h"

TRIPLE::TRIPLE(int x, int y, int z){
	this->x=x;
	this->y=y;
	this->z=z;
}
int TRIPLE::getX(){
	return this->x;
}
int TRIPLE::getY(){
	return this->y;
}
int TRIPLE::getZ(){
	return this->z;
}