#include "ImageBase.h"
#include <stdio.h>
#include <iostream>
#include <vector>

class Pixel
{

    int valeur;

public :

    bool fait;

    Pixel(){
        valeur = 0;
        this->fait = false;
    }
    ~Pixel(){

    }

    int getValeur(){
        return valeur;
    }

    bool estfait(){
        return this->fait;
    }

    void setValeur(int i){
        valeur = i;
    }

    void setTraite(bool b){
        this->fait = b;
    }

};

