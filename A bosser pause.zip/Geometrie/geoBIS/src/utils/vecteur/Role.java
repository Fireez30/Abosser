package utils.vecteur;

public enum Role {begin, end, intersect, undefined}


