package algoGeo;

public class Envellope {

}
