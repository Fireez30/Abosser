#ifndef VOXEL_H
#define VOXEL_H

#include <math.h>
#include <stdio.h>      
#include <stdlib.h>  
#include <vector> 
#include "CPoint.h"
#include <GL/glut.h>


class Voxel {

private:

    CPoint* centre;
    double l;
    std::vector<CPoint>* Coins;
    std::vector<CPoint>* CentresDivision;

public:

	Voxel();
	~Voxel();
	Voxel(CPoint* c, double length);

	CPoint* getCenter();
	double getLength();
	std::vector<CPoint>* getCoins();
	std::vector<CPoint>* getCentresDivisions();

	void tracePoint(CPoint *A, float x,float y,float z);
	void trace(CPoint* A, CPoint* B,CPoint* C,CPoint* D, float x,float y,float z);
	void traceSquelette();
	void AfficheVoxel();
	void computeDivision();	
	void computeCoins();
	void displayDivision();	
	int isInsideSphere(CPoint* cts, double ray);
	int isInsideCylinder(CPoint* cts, CVector* v,double ray);
};

#endif